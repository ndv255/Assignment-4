using Godot;
using System;

public partial class Player : CharacterBody2D
{
	[Export] public float Speed = 200.0f;     
	[Export] public float JumpVelocity = -400.0f; 
	[Export] public float Gravity = 900.0f;       

	[Signal]
	public delegate void StarCountChangedEventHandler(int newCount);
	
	 private AnimatedSprite2D _animatedSprite;
	private int _starCount = 0;
	
	public override void _Ready()
	{
		_animatedSprite = GetNode<AnimatedSprite2D>("AnimatedSprite2D");
		base._Ready();

		var area = GetNodeOrNull<Area2D>("Area2D");
		if (area != null)
		{
			area.BodyEntered += OnBodyEntered;
		}
	}
	private void _on_star_collected()
	{
		AddStar();
	}
	
	public void AddStar()
	{
		_starCount++;
		EmitSignal(SignalName.StarCountChanged, _starCount);
	}
	
	
	
	private void OnBodyEntered(Node body)
	{
		if (body is Enemy)
		{
			GetTree().ChangeSceneToFile("res://Lose_menu.tscn");
		}
	}
	
	public override void _PhysicsProcess(double delta)
	{
		Vector2 velocity = Velocity;

		if (!IsOnFloor())
		{
			velocity.Y += Gravity * (float)delta;
		}
		else if (velocity.Y > 0)
		{
			// Prevent sliding down slopes slowly when standing
			velocity.Y = 0;
		}


		float inputX = Input.GetActionStrength("ui_right") - Input.GetActionStrength("ui_left");
		velocity.X = inputX * Speed;

		if (Input.IsActionJustPressed("ui_accept") && IsOnFloor())
		{
			velocity.Y = JumpVelocity;
		}

		Velocity = velocity;
		MoveAndSlide();
		
		if (!IsOnFloor())
		{
			if (velocity.Y < 0)
				_animatedSprite.Play("jump");
			else
				_animatedSprite.Play("fall");
		}
		else if (Math.Abs(velocity.X) > 5)
		{
			_animatedSprite.Play("walk");
		}
		else
		{
			_animatedSprite.Play("IDLE");
		}


		if (velocity.X != 0)
			_animatedSprite.FlipH = velocity.X < 0;
	}
}
