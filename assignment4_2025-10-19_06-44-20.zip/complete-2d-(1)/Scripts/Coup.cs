using Godot;
using System;

public partial class MessageTrigger : Area2D
{
	[Export] public string Message = "Player touched me!";

	public override void _Ready()
	{
		// Connect the body entered signal
		this.BodyEntered += OnBodyEntered;
	}

	private void OnBodyEntered(Node2D body)
	{
		if (body.Name == "Player")
		{
			GD.Print(Message);
		}
	}
}
