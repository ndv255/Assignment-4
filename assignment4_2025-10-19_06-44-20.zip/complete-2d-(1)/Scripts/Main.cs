using Godot;
using System;

public partial class Main : Node2D
{
	[Export] public int NumEnemies = 10;
	[Export] public PackedScene EnemyScene;
	
	public override void _Ready()
	{
		for(int i=0; i<NumEnemies; i++)
		{
			Enemy e = EnemyScene.Instantiate<Enemy>();
			AddChild(e);
		}
		var player = GetNode<Player>("Player");
		var starUI = GetNode<StarUI>("Player/Camera2D/CanvasLayer");

		if (player != null && starUI != null)
		{
			player.StarCountChanged += starUI.UpdateStars;
		}
		else
		{
			GD.PrintErr("failed");
		}
	}
}
