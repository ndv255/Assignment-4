using Godot;
using System;

public partial class Star3 : Area2D
{
	
	public override void _Ready()
	{
		BodyEntered += OnBodyEntered;
	}

	private void OnBodyEntered(Node body)
	{
		if (body is Player player)
		{
			GetTree().ChangeSceneToFile("res://Scenes/Lose_menu.tscn");
		}
	}
}
